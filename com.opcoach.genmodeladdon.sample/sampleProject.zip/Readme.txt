This project contains a sample model to help for test. 
It is used by genmodeladdon.core.test fragment and can be used at runtime.